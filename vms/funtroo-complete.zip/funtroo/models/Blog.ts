import mongoose, { Schema, Document } from 'mongoose'

export type BlogStatus = 'draft' | 'published' | 'scheduled'

export interface IBlog extends Document {
  title: string
  slug: string
  excerpt: string
  content: string          // Raw HTML
  featuredImage: string
  category: string
  tags: string[]
  author: string
  status: BlogStatus
  scheduledAt: Date | null
  publishedAt: Date | null
  // SEO
  seo: {
    metaTitle: string
    metaDesc: string
    focusKw: string
    secondaryKws: string[]
    canonical: string
    ogImage: string
    noIndex: boolean
  }
  // Stats
  views: number
  readTime: number         // auto-calculated in minutes
  createdAt: Date
  updatedAt: Date
}

const BlogSchema = new Schema<IBlog>({
  title:         { type: String, required: true },
  slug:          { type: String, required: true, unique: true },
  excerpt:       { type: String, default: '' },
  content:       { type: String, default: '' },
  featuredImage: { type: String, default: '' },
  category:      { type: String, default: 'General' },
  tags:          [{ type: String }],
  author:        { type: String, default: 'Funtroo Team' },
  status:        { type: String, enum: ['draft', 'published', 'scheduled'], default: 'draft' },
  scheduledAt:   { type: Date, default: null },
  publishedAt:   { type: Date, default: null },
  seo: {
    metaTitle:     { type: String, default: '' },
    metaDesc:      { type: String, default: '' },
    focusKw:       { type: String, default: '' },
    secondaryKws:  [{ type: String }],
    canonical:     { type: String, default: '' },
    ogImage:       { type: String, default: '' },
    noIndex:       { type: Boolean, default: false },
  },
  views:    { type: Number, default: 0 },
  readTime: { type: Number, default: 1 },
}, { timestamps: true })

// Auto-publish scheduled posts (checked on fetch)
BlogSchema.index({ status: 1, scheduledAt: 1 })
BlogSchema.index({ slug: 1 })

export default mongoose.models.Blog || mongoose.model<IBlog>('Blog', BlogSchema)
