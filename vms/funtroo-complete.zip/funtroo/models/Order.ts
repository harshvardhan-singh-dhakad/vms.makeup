import mongoose, { Schema, Document } from 'mongoose'

export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'returned'
export type PaymentMethod = 'razorpay' | 'cod'
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'refunded'

export interface IOrder extends Document {
  orderNumber: string
  customer: mongoose.Types.ObjectId
  customerSnapshot: { name: string; email: string; phone: string }
  items: {
    product: mongoose.Types.ObjectId
    name: string
    image: string
    price: number
    qty: number
  }[]
  address: {
    line1: string; line2: string; city: string; state: string; pincode: string
  }
  subtotal: number
  cardDiscount: number
  couponDiscount: number
  couponCode: string
  shipping: number
  total: number
  paymentMethod: PaymentMethod
  paymentStatus: PaymentStatus
  razorpayOrderId: string
  razorpayPaymentId: string
  status: OrderStatus
  trackingNumber: string
  notes: string
  createdAt: Date
}

const OrderSchema = new Schema<IOrder>({
  orderNumber:     { type: String, unique: true },
  customer:        { type: Schema.Types.ObjectId, ref: 'Customer' },
  customerSnapshot:{ name: String, email: String, phone: String },
  items: [{
    product: { type: Schema.Types.ObjectId, ref: 'Product' },
    name:    String,
    image:   String,
    price:   Number,
    qty:     Number,
  }],
  address: { line1: String, line2: String, city: String, state: String, pincode: String },
  subtotal:         { type: Number, default: 0 },
  cardDiscount:     { type: Number, default: 0 },
  couponDiscount:   { type: Number, default: 0 },
  couponCode:       { type: String, default: '' },
  shipping:         { type: Number, default: 0 },
  total:            { type: Number, default: 0 },
  paymentMethod:    { type: String, enum: ['razorpay', 'cod'], default: 'cod' },
  paymentStatus:    { type: String, enum: ['pending', 'paid', 'failed', 'refunded'], default: 'pending' },
  razorpayOrderId:  { type: String, default: '' },
  razorpayPaymentId:{ type: String, default: '' },
  status:           { type: String, enum: ['pending','confirmed','processing','shipped','delivered','cancelled','returned'], default: 'pending' },
  trackingNumber:   { type: String, default: '' },
  notes:            { type: String, default: '' },
}, { timestamps: true })

OrderSchema.pre('save', function(next) {
  if (!this.orderNumber) {
    this.orderNumber = 'FT' + Date.now().toString().slice(-8)
  }
  next()
})

export default mongoose.models.Order || mongoose.model<IOrder>('Order', OrderSchema)
