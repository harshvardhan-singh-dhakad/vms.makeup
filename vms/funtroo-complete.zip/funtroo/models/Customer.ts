import mongoose, { Schema, Document } from 'mongoose'

export type CardTier = 'silver' | 'gold' | 'platinum'

export interface ICustomer extends Document {
  name: string
  email: string
  password: string
  phone: string
  role: 'customer' | 'admin'
  addresses: {
    _id?: string
    label: string
    line1: string
    line2: string
    city: string
    state: string
    pincode: string
    isDefault: boolean
  }[]
  card: {
    tier: CardTier
    number: string
    totalSpend: number
    discountPct: number
    joinedAt: Date
  }
  wishlist: string[]
  browsingHistory: string[]
  createdAt: Date
}

const CustomerSchema = new Schema<ICustomer>({
  name:     { type: String, required: true },
  email:    { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  phone:    { type: String },
  role:     { type: String, enum: ['customer', 'admin'], default: 'customer' },
  addresses: [{
    label:     String,
    line1:     String,
    line2:     String,
    city:      String,
    state:     String,
    pincode:   String,
    isDefault: { type: Boolean, default: false },
  }],
  card: {
    tier:        { type: String, enum: ['silver', 'gold', 'platinum'], default: 'silver' },
    number:      { type: String },
    totalSpend:  { type: Number, default: 0 },
    discountPct: { type: Number, default: 5 },
    joinedAt:    { type: Date, default: Date.now },
  },
  wishlist:        [{ type: String }],
  browsingHistory: [{ type: String }],
}, { timestamps: true })

export default mongoose.models.Customer || mongoose.model<ICustomer>('Customer', CustomerSchema)
