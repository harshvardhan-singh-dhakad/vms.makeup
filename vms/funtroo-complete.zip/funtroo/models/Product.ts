import mongoose, { Schema, Document } from 'mongoose'

export interface IProduct extends Document {
  name: string
  slug: string
  description: string
  price: number
  originalPrice: number
  images: string[]
  category: string
  subcategory: string
  tags: string[]
  stock: number
  sku: string
  material: string
  features: string[]
  isWaterproof: boolean
  isRechargeable: boolean
  intensityModes: number
  isFeatured: boolean
  isActive: boolean
  rating: number
  reviewCount: number
  soldCount: number
  createdAt: Date
}

const ProductSchema = new Schema<IProduct>({
  name:           { type: String, required: true },
  slug:           { type: String, required: true, unique: true },
  description:    { type: String, required: true },
  price:          { type: Number, required: true },
  originalPrice:  { type: Number, required: true },
  images:         [{ type: String }],
  category:       { type: String, required: true, enum: ['for-her', 'for-him', 'couples', 'lubricants', 'lingerie', 'accessories'] },
  subcategory:    { type: String },
  tags:           [{ type: String }],
  stock:          { type: Number, default: 0 },
  sku:            { type: String },
  material:       { type: String },
  features:       [{ type: String }],
  isWaterproof:   { type: Boolean, default: false },
  isRechargeable: { type: Boolean, default: false },
  intensityModes: { type: Number, default: 0 },
  isFeatured:     { type: Boolean, default: false },
  isActive:       { type: Boolean, default: true },
  rating:         { type: Number, default: 0 },
  reviewCount:    { type: Number, default: 0 },
  soldCount:      { type: Number, default: 0 },
}, { timestamps: true })

ProductSchema.index({ category: 1, isActive: 1 })
ProductSchema.index({ slug: 1 })
ProductSchema.index({ isFeatured: 1 })

export default mongoose.models.Product || mongoose.model<IProduct>('Product', ProductSchema)
