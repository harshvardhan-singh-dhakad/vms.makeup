'use client'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { useCart } from '@/lib/store'
import { ShoppingBag, Search, User, Menu, X, BookOpen } from 'lucide-react'
import { useState } from 'react'
import CartDrawer from './CartDrawer'

const SHOP_LINKS = [
  { label: 'For Her',    href: '/shop?category=for-her' },
  { label: 'For Him',    href: '/shop?category=for-him' },
  { label: 'Couples',    href: '/shop?category=couples' },
  { label: 'Lubricants', href: '/shop?category=lubricants' },
  { label: 'Lingerie',   href: '/shop?category=lingerie' },
  { label: 'New In',     href: '/shop?sort=createdAt' },
]

export default function Navbar() {
  const { data: session } = useSession()
  const { totalItems, toggleCart } = useCart()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [q, setQ] = useState('')

  return (
    <>
      <header className="sticky top-0 z-50 bg-f-dark shadow-lg">
        <div className="bg-f-purple text-white text-center text-[11px] py-1.5 tracking-wide">
          🚚 Free shipping above ₹999 &nbsp;·&nbsp; 📦 Plain brown box &nbsp;·&nbsp; 💳 COD available pan India
        </div>
        <div className="flex items-center justify-between px-4 md:px-8 h-14">
          <Link href="/" className="font-display text-2xl text-f-light tracking-widest shrink-0">
            FUN<span className="text-f-accent">troo</span>
          </Link>
          <nav className="hidden md:flex gap-5 items-center">
            {SHOP_LINKS.map(c => (
              <Link key={c.href} href={c.href} className="text-[11px] text-f-muted hover:text-f-light tracking-widest uppercase transition">
                {c.label}
              </Link>
            ))}
            <Link href="/blog" className="text-[11px] text-f-accent hover:text-f-light tracking-widest uppercase transition flex items-center gap-1">
              <BookOpen size={12} /> Blog
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            {searchOpen ? (
              <form onSubmit={e => { e.preventDefault(); window.location.href = `/shop?q=${q}` }} className="flex items-center gap-2">
                <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search products..."
                  className="bg-[#2D2773] text-f-light text-sm px-3 py-1.5 rounded-lg border border-f-mid outline-none w-40 placeholder:text-f-muted" />
                <button type="button" onClick={() => setSearchOpen(false)}><X size={16} className="text-f-muted" /></button>
              </form>
            ) : (
              <button onClick={() => setSearchOpen(true)}><Search size={18} className="text-f-muted hover:text-f-light transition" /></button>
            )}
            {session ? (
              <div className="relative group hidden md:block">
                <button><User size={18} className="text-f-muted hover:text-f-light transition" /></button>
                <div className="absolute right-0 top-8 bg-[#2D2773] border border-[#4C1D95] rounded-xl shadow-xl w-48 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-all z-50">
                  <Link href="/account"            className="block px-4 py-2.5 text-sm text-f-muted hover:text-f-light hover:bg-f-dark/30 transition">My Account</Link>
                  <Link href="/account?tab=orders" className="block px-4 py-2.5 text-sm text-f-muted hover:text-f-light hover:bg-f-dark/30 transition">Orders</Link>
                  <Link href="/account?tab=card"   className="block px-4 py-2.5 text-sm text-f-muted hover:text-f-light hover:bg-f-dark/30 transition">My Card</Link>
                  {(session.user as any)?.role === 'admin' && (
                    <Link href="/admin" className="block px-4 py-2.5 text-sm text-f-accent hover:text-white hover:bg-f-purple/30 transition border-t border-[#4C1D95]">Admin Panel</Link>
                  )}
                  <button onClick={() => signOut()} className="block w-full text-left px-4 py-2.5 text-sm text-red-400 hover:bg-f-dark/30 transition border-t border-[#4C1D95]">Sign Out</button>
                </div>
              </div>
            ) : (
              <Link href="/auth/login" className="hidden md:block"><User size={18} className="text-f-muted hover:text-f-light transition" /></Link>
            )}
            <button onClick={toggleCart} className="relative">
              <ShoppingBag size={18} className="text-f-muted hover:text-f-light transition" />
              {totalItems() > 0 && (
                <span className="absolute -top-2 -right-2 bg-f-accent text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">{totalItems()}</span>
              )}
            </button>
            <button className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X size={20} className="text-f-muted" /> : <Menu size={20} className="text-f-muted" />}
            </button>
          </div>
        </div>
        {mobileOpen && (
          <div className="md:hidden bg-[#2D2773] border-t border-[#4C1D95] px-4 py-4 flex flex-col gap-3">
            {SHOP_LINKS.map(c => (
              <Link key={c.href} href={c.href} onClick={() => setMobileOpen(false)} className="text-sm text-f-muted hover:text-f-light transition py-1">{c.label}</Link>
            ))}
            <Link href="/blog" onClick={() => setMobileOpen(false)} className="text-sm text-f-accent hover:text-f-light transition py-1 flex items-center gap-1">
              <BookOpen size={13} /> Blog
            </Link>
            {session ? (
              <>
                <Link href="/account" onClick={() => setMobileOpen(false)} className="text-sm text-f-muted py-1">Account</Link>
                <button onClick={() => signOut()} className="text-left text-sm text-red-400 py-1">Sign Out</button>
              </>
            ) : (
              <Link href="/auth/login" className="text-sm text-f-accent py-1">Login / Register</Link>
            )}
          </div>
        )}
      </header>
      <CartDrawer />
    </>
  )
}
