import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Product from '@/models/Product'

/**
 * GET /api/suggestions?category=for-her&exclude=slug1,slug2&limit=4
 * Returns smart product suggestions based on:
 * 1. Same category (primary)
 * 2. Bestsellers across store (fallback)
 * 3. Excludes current product + cart items
 */
export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category') || ''
    const exclude  = (searchParams.get('exclude') || '').split(',').filter(Boolean)
    const tags     = (searchParams.get('tags')    || '').split(',').filter(Boolean)
    const limit    = parseInt(searchParams.get('limit') || '4')

    let suggestions: any[] = []

    // 1. Same category, matching tags — highest relevance
    if (category && tags.length) {
      suggestions = await Product.find({
        isActive: true,
        category,
        slug: { $nin: exclude },
        tags: { $in: tags },
      }).sort({ soldCount: -1, rating: -1 }).limit(limit)
    }

    // 2. Fill with same-category bestsellers
    if (suggestions.length < limit && category) {
      const filled = await Product.find({
        isActive: true,
        category,
        slug: { $nin: [...exclude, ...suggestions.map(p => p.slug)] },
      }).sort({ soldCount: -1 }).limit(limit - suggestions.length)
      suggestions = [...suggestions, ...filled]
    }

    // 3. Fill remaining with store bestsellers
    if (suggestions.length < limit) {
      const filled = await Product.find({
        isActive: true,
        slug: { $nin: [...exclude, ...suggestions.map(p => p.slug)] },
      }).sort({ soldCount: -1, rating: -1 }).limit(limit - suggestions.length)
      suggestions = [...suggestions, ...filled]
    }

    return NextResponse.json({ suggestions })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
