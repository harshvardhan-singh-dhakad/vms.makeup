import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Order from '@/models/Order'

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  await connectDB()
  const order = await Order.findOne({
    $or: [{ _id: params.id.length === 24 ? params.id : null }, { orderNumber: params.id }]
  }).populate('customer', 'name email phone card')
  if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ order })
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()
    const body  = await req.json()
    const order = await Order.findByIdAndUpdate(params.id, body, { new: true })
    return NextResponse.json({ order })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
