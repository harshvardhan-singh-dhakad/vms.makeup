import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Order from '@/models/Order'
import Customer from '@/models/Customer'
import { getTier, generateCardNumber } from '@/lib/loyalty'

export async function POST(req: NextRequest) {
  try {
    await connectDB()
    const body = await req.json()
    const order = await Order.create(body)

    // Update customer loyalty card after order
    if (body.customer && body.total) {
      const customer = await Customer.findById(body.customer)
      if (customer) {
        const newSpend = (customer.card.totalSpend || 0) + body.total
        const newTier  = getTier(newSpend)
        const discMap  = { silver: 5, gold: 10, platinum: 15 }
        if (!customer.card.number) customer.card.number = generateCardNumber()
        customer.card.totalSpend  = newSpend
        customer.card.tier        = newTier
        customer.card.discountPct = discMap[newTier]
        await customer.save()
      }
    }

    return NextResponse.json({ order }, { status: 201 })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const page       = parseInt(searchParams.get('page')     || '1')
    const limit      = parseInt(searchParams.get('limit')    || '20')
    const status     = searchParams.get('status')    || ''
    const customerId = searchParams.get('customer')  || ''
    const q          = searchParams.get('q')         || ''

    const filter: any = {}
    if (status)     filter.status   = status
    if (customerId) filter.customer = customerId
    if (q)          filter.$or = [
      { orderNumber: new RegExp(q, 'i') },
      { 'customerSnapshot.name':  new RegExp(q, 'i') },
      { 'customerSnapshot.email': new RegExp(q, 'i') },
    ]

    const [orders, total] = await Promise.all([
      Order.find(filter).sort({ createdAt: -1 }).skip((page-1)*limit).limit(limit).populate('customer', 'name email'),
      Order.countDocuments(filter),
    ])

    return NextResponse.json({ orders, total, page, pages: Math.ceil(total/limit) })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
