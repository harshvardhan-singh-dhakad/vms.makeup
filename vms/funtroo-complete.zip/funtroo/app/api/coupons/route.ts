import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Coupon from '@/models/Coupon'

// POST — validate coupon
export async function POST(req: NextRequest) {
  try {
    await connectDB()
    const { code, subtotal } = await req.json()
    const coupon = await Coupon.findOne({ code: code.toUpperCase(), isActive: true })

    if (!coupon)                         return NextResponse.json({ error: 'Invalid coupon code' }, { status: 400 })
    if (coupon.usedCount >= coupon.usageLimit) return NextResponse.json({ error: 'Coupon usage limit reached' }, { status: 400 })
    if (coupon.expiresAt && new Date() > coupon.expiresAt) return NextResponse.json({ error: 'Coupon expired' }, { status: 400 })
    if (subtotal < coupon.minOrder)      return NextResponse.json({ error: `Min order ₹${coupon.minOrder} required` }, { status: 400 })

    const discount = coupon.type === 'percent'
      ? Math.min(Math.round(subtotal * coupon.value / 100), coupon.maxDiscount)
      : Math.min(coupon.value, coupon.maxDiscount)

    return NextResponse.json({ valid: true, discount, coupon: { code: coupon.code, type: coupon.type, value: coupon.value } })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

// GET — list coupons (admin)
export async function GET() {
  await connectDB()
  const coupons = await Coupon.find().sort({ createdAt: -1 })
  return NextResponse.json({ coupons })
}

// PUT — create coupon (admin)
export async function PUT(req: NextRequest) {
  try {
    await connectDB()
    const body   = await req.json()
    const coupon = body._id
      ? await Coupon.findByIdAndUpdate(body._id, body, { new: true })
      : await Coupon.create(body)
    return NextResponse.json({ coupon })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
