import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Blog from '@/models/Blog'

// Auto-publish scheduled posts that are due
async function autoPublish() {
  const now = new Date()
  await Blog.updateMany(
    { status: 'scheduled', scheduledAt: { $lte: now } },
    { $set: { status: 'published', publishedAt: now } }
  )
}

// Estimate read time (avg 200 words/min)
function calcReadTime(html: string): number {
  const text  = html.replace(/<[^>]+>/g, ' ')
  const words = text.trim().split(/\s+/).length
  return Math.max(1, Math.round(words / 200))
}

// Auto-generate slug
function makeSlug(title: string): string {
  return title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '').replace(/-+/g, '-').slice(0, 80)
}

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    await autoPublish()

    const { searchParams } = new URL(req.url)
    const page     = parseInt(searchParams.get('page')     || '1')
    const limit    = parseInt(searchParams.get('limit')    || '10')
    const status   = searchParams.get('status')   || ''
    const category = searchParams.get('category') || ''
    const q        = searchParams.get('q')         || ''
    const adminMode= searchParams.get('admin')     === 'true'
    const tag      = searchParams.get('tag')       || ''

    const filter: any = adminMode ? {} : { status: 'published' }
    if (status   && adminMode) filter.status   = status
    if (category) filter.category = category
    if (tag)      filter.tags     = tag
    if (q)        filter.$or = [
      { title:    new RegExp(q, 'i') },
      { excerpt:  new RegExp(q, 'i') },
      { 'seo.focusKw': new RegExp(q, 'i') },
      { tags:     new RegExp(q, 'i') },
    ]

    const [blogs, total] = await Promise.all([
      Blog.find(filter)
        .select(adminMode ? '-content' : '-content')   // list view — no content
        .sort({ publishedAt: -1, createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Blog.countDocuments(filter),
    ])

    return NextResponse.json({ blogs, total, page, pages: Math.ceil(total / limit) })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    await connectDB()
    const body = await req.json()

    // Slug
    if (!body.slug && body.title) body.slug = makeSlug(body.title)

    // Read time
    if (body.content) body.readTime = calcReadTime(body.content)

    // publishedAt
    if (body.status === 'published' && !body.publishedAt) body.publishedAt = new Date()

    // SEO defaults
    if (!body.seo) body.seo = {}
    if (!body.seo.metaTitle && body.title)  body.seo.metaTitle = body.title.slice(0, 60)
    if (!body.seo.metaDesc  && body.excerpt) body.seo.metaDesc = body.excerpt.slice(0, 160)

    const blog = await Blog.create(body)
    return NextResponse.json({ blog }, { status: 201 })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
