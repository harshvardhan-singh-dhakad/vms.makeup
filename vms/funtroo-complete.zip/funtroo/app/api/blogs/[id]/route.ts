import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Blog from '@/models/Blog'

function calcReadTime(html: string): number {
  const words = html.replace(/<[^>]+>/g, ' ').trim().split(/\s+/).length
  return Math.max(1, Math.round(words / 200))
}

// GET by slug or _id — also increments views
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()
    const isId  = params.id.length === 24
    const blog  = await Blog.findOne(isId ? { _id: params.id } : { slug: params.id })
    if (!blog) return NextResponse.json({ error: 'Blog not found' }, { status: 404 })

    // Increment views (only for public slug fetch)
    if (!isId) await Blog.findByIdAndUpdate(blog._id, { $inc: { views: 1 } })

    return NextResponse.json({ blog })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()
    const body = await req.json()

    // Recalculate read time on content update
    if (body.content) body.readTime = calcReadTime(body.content)

    // Set publishedAt when first publishing
    if (body.status === 'published') {
      const existing = await Blog.findById(params.id)
      if (existing && existing.status !== 'published') body.publishedAt = new Date()
    }

    const blog = await Blog.findByIdAndUpdate(params.id, body, { new: true })
    return NextResponse.json({ blog })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()
    await Blog.findByIdAndDelete(params.id)
    return NextResponse.json({ success: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
