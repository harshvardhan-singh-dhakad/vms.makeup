import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Order from '@/models/Order'
import Customer from '@/models/Customer'
import Product from '@/models/Product'

export async function GET() {
  try {
    await connectDB()
    const now   = new Date()
    const month = new Date(now.getFullYear(), now.getMonth(), 1)
    const week  = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

    const [
      totalOrders, monthOrders, weekOrders,
      totalCustomers, newCustomers,
      totalProducts, lowStock,
      revenueAgg, monthRevenueAgg,
      recentOrders,
      ordersByStatus,
      topProducts,
    ] = await Promise.all([
      Order.countDocuments(),
      Order.countDocuments({ createdAt: { $gte: month } }),
      Order.countDocuments({ createdAt: { $gte: week  } }),
      Customer.countDocuments({ role: 'customer' }),
      Customer.countDocuments({ createdAt: { $gte: month }, role: 'customer' }),
      Product.countDocuments({ isActive: true }),
      Product.countDocuments({ isActive: true, stock: { $lte: 5 } }),
      Order.aggregate([{ $match: { paymentStatus: 'paid' } }, { $group: { _id: null, total: { $sum: '$total' } } }]),
      Order.aggregate([{ $match: { paymentStatus: 'paid', createdAt: { $gte: month } } }, { $group: { _id: null, total: { $sum: '$total' } } }]),
      Order.find().sort({ createdAt: -1 }).limit(8).select('orderNumber customerSnapshot total status createdAt'),
      Order.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
      Order.aggregate([
        { $unwind: '$items' },
        { $group: { _id: '$items.name', revenue: { $sum: { $multiply: ['$items.price', '$items.qty'] } }, qty: { $sum: '$items.qty' } } },
        { $sort: { revenue: -1 } }, { $limit: 5 },
      ]),
    ])

    return NextResponse.json({
      orders:    { total: totalOrders, thisMonth: monthOrders, thisWeek: weekOrders },
      customers: { total: totalCustomers, new: newCustomers },
      products:  { total: totalProducts, lowStock },
      revenue:   { total: revenueAgg[0]?.total || 0, thisMonth: monthRevenueAgg[0]?.total || 0 },
      recentOrders,
      ordersByStatus,
      topProducts,
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
