import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Product from '@/models/Product'

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const category  = searchParams.get('category') || ''
    const featured  = searchParams.get('featured') === 'true'
    const q         = searchParams.get('q') || ''
    const page      = parseInt(searchParams.get('page') || '1')
    const limit     = parseInt(searchParams.get('limit') || '12')
    const sort      = searchParams.get('sort') || 'createdAt'
    const adminMode = searchParams.get('admin') === 'true'

    const filter: any = adminMode ? {} : { isActive: true }
    if (category) filter.category = category
    if (featured) filter.isFeatured = true
    if (q) filter.$or = [{ name: new RegExp(q, 'i') }, { tags: new RegExp(q, 'i') }]

    const sortMap: any = {
      createdAt:  { createdAt: -1 },
      price_asc:  { price:  1 },
      price_desc: { price: -1 },
      popular:    { soldCount: -1 },
      rating:     { rating: -1 },
    }

    const [products, total] = await Promise.all([
      Product.find(filter).sort(sortMap[sort] || { createdAt: -1 }).skip((page-1)*limit).limit(limit),
      Product.countDocuments(filter),
    ])

    return NextResponse.json({ products, total, page, pages: Math.ceil(total/limit) })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    await connectDB()
    const body = await req.json()

    // auto-generate slug
    if (!body.slug && body.name) {
      body.slug = body.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
    }

    const product = await Product.create(body)
    return NextResponse.json({ product }, { status: 201 })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
