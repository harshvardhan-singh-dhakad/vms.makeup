import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Product from '@/models/Product'

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  await connectDB()
  const product = await Product.findOne({ $or: [{ _id: params.id.length === 24 ? params.id : null }, { slug: params.id }] })
  if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ product })
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()
    const body    = await req.json()
    const product = await Product.findByIdAndUpdate(params.id, body, { new: true })
    return NextResponse.json({ product })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  await connectDB()
  await Product.findByIdAndUpdate(params.id, { isActive: false })
  return NextResponse.json({ success: true })
}
