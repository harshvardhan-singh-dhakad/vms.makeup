import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { connectDB } from '@/lib/mongodb'
import Customer from '@/models/Customer'
import { generateCardNumber } from '@/lib/loyalty'

export async function POST(req: NextRequest) {
  try {
    const { name, email, password, phone } = await req.json()
    if (!name || !email || !password) return NextResponse.json({ error: 'Missing fields' }, { status: 400 })

    await connectDB()
    const exists = await Customer.findOne({ email: email.toLowerCase() })
    if (exists) return NextResponse.json({ error: 'Email already registered' }, { status: 400 })

    const hashed = await bcrypt.hash(password, 10)
    const customer = await Customer.create({
      name, email, phone,
      password: hashed,
      card: { tier: 'silver', number: generateCardNumber(), totalSpend: 0, discountPct: 5 },
    })

    return NextResponse.json({ success: true, id: customer._id })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const page  = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const q     = searchParams.get('q') || ''

    const query = q ? { $or: [{ name: new RegExp(q, 'i') }, { email: new RegExp(q, 'i') }] } : {}
    const [customers, total] = await Promise.all([
      Customer.find(query).select('-password').sort({ createdAt: -1 }).skip((page-1)*limit).limit(limit),
      Customer.countDocuments(query),
    ])
    return NextResponse.json({ customers, total, page, pages: Math.ceil(total/limit) })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
