'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Zap } from 'lucide-react'

export default function LoginPage() {
  const router = useRouter()
  const [form, setForm]   = useState({ email: '', password: '' })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const res = await signIn('credentials', { ...form, redirect: false })
    setLoading(false)
    if (res?.ok) { toast.success('Welcome back!'); router.push('/') }
    else toast.error('Invalid email or password')
  }

  return (
    <div className="min-h-screen bg-f-dark flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <Link href="/" className="font-display text-3xl text-f-light tracking-widest">FUN<span className="text-f-accent">troo</span></Link>
          <p className="text-f-muted text-sm mt-2">Sign in to your account</p>
        </div>
        <div className="bg-[#2D2773] border border-[#4C1D95] rounded-2xl p-7">
          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { key: 'email',    label: 'Email',    type: 'email'    },
              { key: 'password', label: 'Password', type: 'password' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs text-f-muted mb-1.5">{f.label}</label>
                <input type={f.type} value={(form as any)[f.key]}
                  onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  className="w-full bg-[#1E1B4B] border border-[#4C1D95] rounded-xl px-3 py-2.5 text-sm text-f-light outline-none focus:border-f-accent placeholder:text-f-muted"
                  required />
              </div>
            ))}
            <button type="submit" disabled={loading}
              className="w-full py-3 bg-f-purple text-white rounded-xl text-sm font-medium hover:bg-f-mid transition disabled:opacity-60 mt-2">
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
          <p className="text-center text-xs text-f-muted mt-5">
            Don't have an account?{' '}
            <Link href="/auth/register" className="text-f-accent hover:underline">Create one free</Link>
          </p>
        </div>
        <div className="mt-4 p-3 bg-[#2D2773] rounded-xl border border-[#4C1D95] text-center">
          <p className="text-xs text-f-accent flex items-center justify-center gap-1"><Zap size={11} className="fill-f-accent" /> Sign up &amp; get a free loyalty card — 5% off every order</p>
        </div>
      </div>
    </div>
  )
}
