'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Zap, Star } from 'lucide-react'

export default function RegisterPage() {
  const router = useRouter()
  const [form, setForm]   = useState({ name: '', email: '', phone: '', password: '' })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (form.password.length < 6) return toast.error('Password must be at least 6 characters')
    setLoading(true)
    const res  = await fetch('/api/customers', { method: 'POST', body: JSON.stringify(form), headers: { 'Content-Type': 'application/json' } })
    const data = await res.json()
    if (data.error) { toast.error(data.error); setLoading(false); return }
    await signIn('credentials', { email: form.email, password: form.password, redirect: false })
    toast.success('Account created! Your Silver Card is ready 🎉')
    router.push('/')
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-f-dark flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <Link href="/" className="font-display text-3xl text-f-light tracking-widest">FUN<span className="text-f-accent">troo</span></Link>
          <p className="text-f-muted text-sm mt-2">Create your free account</p>
        </div>

        {/* Card preview */}
        <div className="card-silver card-shine rounded-xl p-4 mb-4 text-white flex items-center justify-between">
          <div>
            <p className="text-[9px] opacity-60 uppercase tracking-widest">You'll receive</p>
            <p className="font-display text-lg">Funtroo Silver Card</p>
          </div>
          <div className="flex items-center gap-1 bg-white/10 px-3 py-1.5 rounded-full">
            <Zap size={13} className="fill-white" /><span className="text-sm font-bold">5% OFF</span>
          </div>
        </div>

        <div className="bg-[#2D2773] border border-[#4C1D95] rounded-2xl p-7">
          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { key: 'name',     label: 'Full Name', type: 'text'     },
              { key: 'email',    label: 'Email',     type: 'email'    },
              { key: 'phone',    label: 'Phone',     type: 'tel'      },
              { key: 'password', label: 'Password',  type: 'password' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs text-f-muted mb-1.5">{f.label}</label>
                <input type={f.type} value={(form as any)[f.key]}
                  onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  className="w-full bg-[#1E1B4B] border border-[#4C1D95] rounded-xl px-3 py-2.5 text-sm text-f-light outline-none focus:border-f-accent placeholder:text-f-muted"
                  required={f.key !== 'phone'} />
              </div>
            ))}
            <p className="text-[10px] text-f-muted">By signing up you agree to our terms. You must be 18+ to use Funtroo.</p>
            <button type="submit" disabled={loading}
              className="w-full py-3 bg-f-purple text-white rounded-xl text-sm font-medium hover:bg-f-mid transition disabled:opacity-60">
              {loading ? 'Creating...' : 'Create Account & Get Card'}
            </button>
          </form>
          <p className="text-center text-xs text-f-muted mt-5">
            Already have an account? <Link href="/auth/login" className="text-f-accent hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
