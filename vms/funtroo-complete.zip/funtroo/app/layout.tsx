import type { Metadata } from 'next'
import './globals.css'
import { Toaster } from 'react-hot-toast'
import Providers from '@/components/Providers'

export const metadata: Metadata = {
  title: 'Funtroo — Wellness, Intimately',
  description: 'Premium adult wellness products. Discreet delivery across India. Plain packaging. COD available.',
  robots: 'noindex, nofollow',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>
          {children}
          <Toaster position="top-right" toastOptions={{
            style: { background: '#1E1B4B', color: '#EDE9FE', fontSize: '13px' },
          }} />
        </Providers>
      </body>
    </html>
  )
}
