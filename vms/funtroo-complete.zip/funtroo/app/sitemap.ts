import { MetadataRoute } from 'next'
import { connectDB } from '@/lib/mongodb'
import Blog from '@/models/Blog'
import Product from '@/models/Product'

const BASE = 'https://funtroo.in'

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  await connectDB()

  const [blogs, products] = await Promise.all([
    Blog.find({ status: 'published' }).select('slug updatedAt').lean(),
    Product.find({ isActive: true }).select('slug updatedAt').lean(),
  ])

  const staticPages: MetadataRoute.Sitemap = [
    { url: BASE,            lastModified: new Date(), changeFrequency: 'daily',   priority: 1.0 },
    { url: `${BASE}/shop`,  lastModified: new Date(), changeFrequency: 'daily',   priority: 0.9 },
    { url: `${BASE}/blog`,  lastModified: new Date(), changeFrequency: 'weekly',  priority: 0.8 },
    { url: `${BASE}/auth/register`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.5 },
  ]

  const blogPages: MetadataRoute.Sitemap = (blogs as any[]).map(b => ({
    url:             `${BASE}/blog/${b.slug}`,
    lastModified:    new Date(b.updatedAt),
    changeFrequency: 'weekly' as const,
    priority:        0.8,
  }))

  const productPages: MetadataRoute.Sitemap = (products as any[]).map(p => ({
    url:             `${BASE}/product/${p.slug}`,
    lastModified:    new Date(p.updatedAt),
    changeFrequency: 'weekly' as const,
    priority:        0.7,
  }))

  return [...staticPages, ...blogPages, ...productPages]
}
