/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        f: {
          dark:    '#1E1B4B',
          purple:  '#6B21A8',
          mid:     '#7C3AED',
          accent:  '#A855F7',
          light:   '#EDE9FE',
          soft:    '#F5F3FF',
          border:  '#DDD6FE',
          muted:   '#A78BFA',
          pink:    '#BE185D',
          green:   '#065F46',
          greenBg: '#D1FAE5',
          gray:    '#6B7280',
          grayBg:  '#F3F4F6',
        },
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'serif'],
        sans:    ['"DM Sans"', 'sans-serif'],
      },
      typography: (theme) => ({
        DEFAULT: {
          css: {
            maxWidth: 'none',
            color: theme('colors.f.gray'),
            a: { color: theme('colors.f.purple'), textDecoration: 'none', '&:hover': { textDecoration: 'underline' } },
            'h2,h3,h4': { fontFamily: '"Cormorant Garamond", serif', color: theme('colors.f.dark') },
            blockquote: { borderLeftColor: theme('colors.f.purple'), backgroundColor: theme('colors.f.soft'), borderRadius: '0 12px 12px 0', padding: '12px 20px' },
            code: { backgroundColor: theme('colors.f.soft'), color: theme('colors.f.purple'), padding: '2px 6px', borderRadius: '4px', fontWeight: '400' },
            'code::before': { content: '""' },
            'code::after':  { content: '""' },
            pre: { backgroundColor: theme('colors.f.dark') },
          },
        },
      }),
    },
  },
  plugins: [require('@tailwindcss/typography')],
}
